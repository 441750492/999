package com.github.lyrric;

import com.github.lyrric.ui.MainFrame;

/**
 * Created on 2020-07-21.
 *
 * @author wangxiaodong
 */
public class Main {

    public static void main(String[] args) {
        new MainFrame();
    }

}
